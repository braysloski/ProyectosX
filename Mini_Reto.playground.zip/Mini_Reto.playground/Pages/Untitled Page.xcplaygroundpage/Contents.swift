// Bray Talavera

import UIKit

//Declaración de variables

var indice = 0..<101

for indice in 0..<101{
    
    if indice % 5 == 0 { //Verifica si es divisible entre 5
        print("#\(indice) Bingo")
    } //Fin de (if BINGO) y termina de verificar
    
    if indice % 2 == 0 { //Verifica
        print("#\(indice) Es Par")
    }//Fin de (if PAR) y termina de verificar
    
    /*else { //Si no es par entonces es IMPAR
        print("#\(indice) Es Impar")
    }*/
    
    if indice % 2 != 0 {
        print("#\(indice) Es Impar")
    }
    
    if indice >= 30 && indice <= 40 { //Verifica
        print("#\(indice) VIVA SWIFT!!!")
    } //Termina de verificar
}

